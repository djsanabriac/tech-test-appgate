package co.djsanabriac.appgate.appgatetechtest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AppgateTechTestApplication {

	public static void main(String[] args) {
		SpringApplication.run(AppgateTechTestApplication.class, args);
	}

}
